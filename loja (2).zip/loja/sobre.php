<?php include("cabecalho.php"); ?>
	
	<h1>Sobre</h1>
	<p>Pagina de teste no treinamento PHP Alura.</p>


<?php include("rodape.php"); ?>