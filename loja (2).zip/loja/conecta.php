<?php
	$conexao = mysqli_connect('localhost', 'root', '', 'loja');
//$conexao = mysqli_connect('mysql.hostinger.com.br', 'u537583186_loja', 'lojaloja', 'u537583186_loja');
